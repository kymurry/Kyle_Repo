import num_square as sq

class SoRow(object):

    def __init__(self):
        self.
