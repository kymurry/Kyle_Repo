from guizero import App

app = App()